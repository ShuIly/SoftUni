﻿public class Person
{
    private string firstName;
    private string lastName;
    private int age;

    public string FirstName
    {
        get => this.firstName;
        set => this.firstName = value;
    }

    public string LastName
    {
        get => this.lastName;
        set => this.lastName = value;
    }

    public int Age
    {
        get => this.age;
        set => this.age = value;
    }

    public Person(string firstName, string lastName, int age)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
    }

    public override string ToString()
    {
        return $"{this.FirstName} {this.LastName} is a {this.Age} years old";
    }
}